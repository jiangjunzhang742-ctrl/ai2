package com.xiaomo.assistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * 混合路由:
 *  1. 本地规则(离线、零延迟):回桌面 / 返回 / 打开某应用
 *  2. 其余交给云端模型,按"看屏幕 → 决策一步 → 执行 → 再看屏幕"循环完成多步骤任务
 */
object Agent {
    private const val MAX_STEPS = 15
    private val SENSITIVE = listOf("支付", "付款", "转账", "密码", "删除", "卸载", "红包", "提现", "确认订单", "pay", "password", "delete")

    private val SYSTEM = """
你是「小墨」,用户手机上的语音助手:温和、简洁、偶尔俏皮。你通过无障碍服务一步步操作手机完成用户目标。
每次只输出一个 JSON,不要任何多余文字:
{"thought":"简短思考","action":"动作","index":编号,"text":"文字","direction":"up或down","app":"应用名","reply":"对用户说的话"}
动作:
- open_app(app):按名称打开应用
- click(index):点击界面里编号为 index 的元素
- type(index,text):向可输入元素输入文字
- enter:按输入法的回车/搜索键
- scroll(direction):滚动页面
- back / home / wait
- speak(reply):中途向用户说一句话
- done(reply):任务完成或无法完成,reply 用一两句口语告诉用户结果
规则:只用当前界面里存在的编号;每步只做一件事;不要进行支付、转账、删除、输入密码等操作,遇到就 done 并告知用户;回复要适合语音播报,不要太长。
""".trimIndent()

    suspend fun run(ctx: Context, goal: String, say: suspend (String) -> Unit): String {
        Story.voice(ctx, goal.replace(" ", ""))?.let { return it }
        Web.voice(ctx, goal.replace(" ", ""))?.let { return it }
        val svc = AgentAccessibilityService.instance ?: return "请先在系统设置里开启小墨的无障碍服务"
        local(svc, goal)?.let { return it }
        return plan(ctx, svc, goal, say)
    }

    private fun local(svc: AgentAccessibilityService, g: String): String? {
        val t = g.replace(" ", "").trimEnd('。', '!')
        return when {
            Regex("^(回到|返回)?(桌面|主屏幕|主页)$").matches(t) -> { svc.home(); "好的" }
            t == "返回" || t == "后退" -> { svc.back(); "好的" }
            t.contains("最近任务") -> { svc.recents(); "好的" }
            else -> {
                val name = Regex("^(?:请)?(?:帮我)?打开(.{1,10})$").find(t)?.groupValues?.get(1)
                if (name != null && name.none { it in "给发搜并然再和找去在" }) {
                    if (svc.openApp(name)) "已打开$name" else "没找到$name"
                } else null
            }
        }
    }

    private suspend fun plan(
        ctx: Context, svc: AgentAccessibilityService, goal: String, say: suspend (String) -> Unit
    ): String {
        if (Prefs.get(ctx, "api_key", "").isBlank()) return "还没有配置云端模型密钥"
        val hist = mutableListOf<Pair<String, String>>()
        var note = ""
        for (step in 1..MAX_STEPS) {
            hist.add("user" to "${note}目标:$goal\n第${step}步,当前界面:\n${svc.dumpScreen()}")
            note = ""
            val reply = try {
                Llm.chat(ctx, SYSTEM, hist.takeLast(7))
            } catch (e: Exception) {
                return "云端模型出错:${e.message}"
            }
            hist.add("assistant" to reply)
            val a = parse(reply) ?: return "我没看懂模型的回复"
            val idx = a.optInt("index", -1)
            when (a.optString("action")) {
                "done" -> return a.optString("reply", "好了")
                "speak" -> say(a.optString("reply"))
                "open_app" -> if (!svc.openApp(a.optString("app"))) note = "上一步失败:没找到这个应用\n"
                "click" -> {
                    val label = svc.labelOf(idx)
                    if (SENSITIVE.any { label.contains(it, ignoreCase = true) })
                        return "这一步涉及支付、删除或密码,我先停下来,请你自己确认"
                    if (!svc.click(idx)) note = "上一步失败:点击无效\n"
                }
                "type" -> if (!svc.type(idx, a.optString("text"))) note = "上一步失败:无法输入\n"
                "enter" -> svc.enter()
                "scroll" -> svc.scroll(a.optString("direction") == "up")
                "back" -> svc.back()
                "home" -> svc.home()
                "wait" -> {}
                else -> note = "上一步失败:未知动作\n"
            }
            delay(1200)
        }
        return "步骤有点多,我先停下了"
    }

    private fun parse(s: String): JSONObject? = try {
        JSONObject(s.substring(s.indexOf('{'), s.lastIndexOf('}') + 1))
    } catch (e: Exception) { null }
}

/** OpenAI 兼容的 /chat/completions 客户端(DeepSeek、通义、Moonshot、OpenRouter 等都能用)。 */
object Llm {
    suspend fun chat(ctx: Context, system: String, msgs: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val base = Prefs.get(ctx, "base_url", "https://api.deepseek.com/v1").trimEnd('/')
            val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system))
            msgs.forEach { arr.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val body = JSONObject()
                .put("model", Prefs.get(ctx, "model", "deepseek-chat"))
                .put("messages", arr)
                .put("temperature", 0.2)
            val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer " + Prefs.get(ctx, "api_key", ""))
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IOException("HTTP $code ${text.take(150)}")
            JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
}
