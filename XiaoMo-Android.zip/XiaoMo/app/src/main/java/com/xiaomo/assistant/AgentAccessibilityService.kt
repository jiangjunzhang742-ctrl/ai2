package com.xiaomo.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** 小墨的"手":读取屏幕(带编号)并执行点击、输入、滚动等动作。 */
class AgentAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: AgentAccessibilityService? = null
    }

    private val nodes = ArrayList<AccessibilityNodeInfo>()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** 把当前界面压缩成带编号的文本,密码框内容不外传。 */
    fun dumpScreen(): String {
        val root = rootInActiveWindow ?: return "(无法读取界面)"
        nodes.clear()
        val sb = StringBuilder("应用:${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo) {
            if (nodes.size >= 120 || !n.isVisibleToUser) return
            val text = if (n.isPassword) "[密码框]" else n.text?.toString()?.take(40)
            val desc = n.contentDescription?.toString()?.take(40)
            val interactive = n.isClickable || n.isEditable || n.isScrollable
            if (interactive || !text.isNullOrBlank() || !desc.isNullOrBlank()) {
                val flags = buildList {
                    if (n.isClickable) add("可点")
                    if (n.isEditable) add("可输入")
                    if (n.isScrollable) add("可滚动")
                }.joinToString("/")
                sb.append("[${nodes.size}] ${n.className?.toString()?.substringAfterLast('.')} ")
                if (!text.isNullOrBlank()) sb.append("\"$text\" ")
                if (!desc.isNullOrBlank()) sb.append("desc=\"$desc\" ")
                sb.append(flags).append('\n')
                nodes.add(n)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return sb.toString()
    }

    fun labelOf(i: Int): String {
        val n = nodes.getOrNull(i) ?: return ""
        return "${n.text ?: ""} ${n.contentDescription ?: ""} ${n.viewIdResourceName ?: ""}"
    }

    fun click(i: Int): Boolean {
        val orig = nodes.getOrNull(i) ?: return false
        var n: AccessibilityNodeInfo? = orig
        while (n != null) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
        }
        val r = Rect()
        orig.getBoundsInScreen(r)
        tap(r.exactCenterX(), r.exactCenterY())
        return true
    }

    fun type(i: Int, text: String): Boolean {
        val n = nodes.getOrNull(i) ?: return false
        if (n.isPassword) return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun enter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val f = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun scroll(up: Boolean): Boolean {
        val n = nodes.firstOrNull { it.isScrollable } ?: return false
        return n.performAction(
            if (up) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        )
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val q = name.lowercase()
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val ri = pm.queryIntentActivities(launcher, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) } ?: return false
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try { startActivity(i); true } catch (e: Exception) { false }
    }

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build(),
            null, null
        )
    }
}
