package com.xiaomo.assistant

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream

/** 本地资料库:导入的文件、抓取的网页、粘贴的文本。检索用 2 字组合(bigram)重合度,纯本地、免模型。 */
object Library {
    @Volatile var lastUsed: List<String> = emptyList()   // 最近一次检索实际用到的资料标题

    class Item(val id: String, val title: String, val source: String, val enabled: Boolean, val chars: Int)

    private fun dir(ctx: Context) = File(ctx.filesDir, "library").apply { mkdirs() }
    private fun idx(ctx: Context) = File(dir(ctx), "index.json")

    fun list(ctx: Context): List<Item> = try {
        val a = JSONArray(idx(ctx).readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Item(o.getString("id"), o.getString("title"), o.getString("source"), o.getBoolean("enabled"), o.getInt("chars"))
        }
    } catch (e: Exception) { emptyList() }

    private fun save(ctx: Context, items: List<Item>) {
        val a = JSONArray()
        items.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("source", it.source)
                .put("enabled", it.enabled).put("chars", it.chars))
        }
        idx(ctx).writeText(a.toString())
    }

    fun add(ctx: Context, title: String, source: String, text: String): Item {
        val t = text.take(2_000_000)
        val id = System.currentTimeMillis().toString()
        File(dir(ctx), "$id.txt").writeText(t)
        val item = Item(id, title.ifBlank { "未命名" }.take(60), source, true, t.length)
        save(ctx, list(ctx) + item)
        return item
    }

    fun toggle(ctx: Context, id: String) =
        save(ctx, list(ctx).map { if (it.id == id) Item(it.id, it.title, it.source, !it.enabled, it.chars) else it })

    fun delete(ctx: Context, id: String) {
        File(dir(ctx), "$id.txt").delete()
        save(ctx, list(ctx).filter { it.id != id })
    }

    private fun grams(s: String): Set<String> {
        val t = s.filter { it.isLetterOrDigit() }.lowercase()
        return if (t.length < 2) emptySet() else (0 until t.length - 1).map { t.substring(it, it + 2) }.toSet()
    }

    /** 取最相关的几段(每段约 700 字)。 */
    fun retrieve(ctx: Context, query: String, k: Int = 4): String {
        lastUsed = emptyList()
        val q = grams(query)
        if (q.isEmpty()) return ""
        val scored = ArrayList<Triple<Int, String, String>>()
        for (item in list(ctx).filter { it.enabled }) {
            val f = File(dir(ctx), "${item.id}.txt")
            if (!f.exists()) continue
            val t = f.readText()
            val base = item.title.substringBeforeLast('.')
            val named = base.length >= 2 && query.contains(base)   // 指令里点了名的资料优先
            var i = 0
            while (i < t.length) {
                val c = t.substring(i, minOf(t.length, i + 700))
                val cg = grams(c)
                val s = q.count { it in cg } + (if (named) 3 else 0)
                if (s > 1) scored.add(Triple(s, item.title, "《${item.title}》$c"))
                i += 600
            }
        }
        val top = scored.sortedByDescending { it.first }.take(k)
        lastUsed = top.map { it.second }.distinct()
        return top.joinToString("\n---\n") { it.third }
    }

    // ---------- 导入本地文件:txt/md/csv/json/html/docx/epub ----------
    suspend fun importUri(ctx: Context, uri: Uri): Item = withContext(Dispatchers.IO) {
        var name = "文件"
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i)
            }
        }
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readLimited(20_000_000) }
            ?: throw IOException("读不了这个文件")
        val text = when (name.substringAfterLast('.', "").lowercase()) {
            "docx" -> zipText(bytes, { it == "word/document.xml" }) { x ->
                unescape(x.replace("</w:p>", "\n").replace(Regex("<[^>]+>"), ""))
            }
            "epub" -> zipText(bytes, { it.endsWith(".xhtml") || it.endsWith(".html") || it.endsWith(".htm") }) {
                Web.htmlToText(it)
            }
            "html", "htm" -> Web.htmlToText(decodeText(bytes))
            "pdf" -> throw IOException("暂不支持 PDF,请先转成 txt 或 docx")
            else -> decodeText(bytes)
        }
        if (text.isBlank()) throw IOException("没读到文字内容")
        val bad = text.count { it == '\uFFFD' || (it < ' ' && it != '\n' && it != '\t' && it != '\r') }
        if (bad > text.length / 20) throw IOException("看起来不是文本文件")
        add(ctx, name, "本地文件", text)
    }

    private fun decodeText(b: ByteArray): String = try {
        Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString()
    } catch (e: CharacterCodingException) {
        String(b, Charset.forName("GBK"))
    }

    private fun unescape(s: String) =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    private fun zipText(bytes: ByteArray, match: (String) -> Boolean, conv: (String) -> String): String {
        val sb = StringBuilder()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (match(e.name)) sb.append(conv(String(z.readBytes(), Charsets.UTF_8))).append('\n')
                e = z.nextEntry
            }
        }
        return sb.toString()
    }
}
