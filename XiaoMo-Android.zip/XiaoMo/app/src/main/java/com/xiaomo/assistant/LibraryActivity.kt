package com.xiaomo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** 资料库 + 联网:搜索、抓网页入库、下载任意文件、导入本地文件。也是系统“分享”目标。 */
class LibraryActivity : Activity() {
    private val scope = MainScope()
    private lateinit var url: EditText
    private lateinit var adapter: ArrayAdapter<String>
    private var items: List<Library.Item> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            fitsSystemWindows = true
        }
        setContentView(root)

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun row(vararg v: View) = root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            v.forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        })

        root.addView(TextView(this).apply {
            text = "📚 资料库:写小说、角色扮演、语音问答会自动参考「✓」的资料\n点一下启用/停用,长按删除。浏览器里「分享」到小墨也能直接入库或下载。"
            textSize = 14f
        })
        url = EditText(this).apply { hint = "关键词,或粘贴网址"; setSingleLine() }
        root.addView(url)

        row(
            btn("🔍 搜索") { search() },
            btn("🌐 网页入库") { addUrl(url.text.toString().trim()) },
            btn("⬇ 下载文件") { download(url.text.toString().trim()) }
        )
        row(btn("📂 导入本地文件") { pick() }, btn("📋 粘贴文本入库") { pasteText() })

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ArrayList<String>())
        val list = ListView(this)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> Library.toggle(this, items[pos].id); refresh() }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this).setTitle("删除「${items[pos].title}」?")
                .setPositiveButton("删除") { _, _ -> Library.delete(this, items[pos].id); refresh() }
                .setNegativeButton("取消", null).show()
            true
        }
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { url.setText(Regex("https?://\\S+").find(it)?.value ?: it) }
        }
        refresh()
    }

    private fun refresh() {
        items = Library.list(this)
        adapter.clear()
        adapter.addAll(items.map { "${if (it.enabled) "✓" else "✗"} ${it.title}(${it.chars}字)\n${it.source}" })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun work(msg: String, f: suspend () -> String) {
        toast(msg)
        scope.launch {
            try { toast(f()) } catch (e: Exception) { toast("出错:${e.message}") }
        }
    }

    private fun search() {
        val q = url.text.toString().trim()
        if (q.isEmpty()) { toast("先输入关键词"); return }
        work("搜索中…") {
            val hits = Web.search(this@LibraryActivity, q)
            if (hits.isEmpty()) "没有结果(可在主界面换搜索引擎地址)"
            else {
                AlertDialog.Builder(this@LibraryActivity).setTitle("搜索结果")
                    .setItems(hits.map { "${it.title}\n${it.snippet.take(60)}" }.toTypedArray()) { _, i -> choose(hits[i]) }
                    .setNegativeButton("关闭", null).show()
                "找到 ${hits.size} 条"
            }
        }
    }

    private fun choose(h: Web.Hit) {
        AlertDialog.Builder(this).setTitle(h.title).setMessage(h.url)
            .setPositiveButton("入库") { _, _ -> addUrl(h.url) }
            .setNegativeButton("下载") { _, _ -> download(h.url) }
            .setNeutralButton("取消", null).show()
    }

    private fun addUrl(u: String) {
        if (!u.startsWith("http")) { toast("请先粘贴网址"); return }
        work("抓取中…") {
            val (title, text) = Web.fetchText(u, 200_000)
            Library.add(this@LibraryActivity, title, u, text)
            refresh()
            "已入库:$title(${text.length}字)"
        }
    }

    private fun download(u: String) {
        if (!u.startsWith("http")) { toast("请先粘贴下载链接"); return }
        work("准备下载…") { "已开始下载 → " + Downloader.enqueue(this@LibraryActivity, u) }
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 9)
    }

    private fun pasteText() {
        val e = EditText(this).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = 5 }
        AlertDialog.Builder(this).setTitle("粘贴文本").setView(e)
            .setPositiveButton("入库") { _, _ ->
                val t = e.text.toString()
                if (t.isNotBlank()) {
                    Library.add(this, t.trim().take(20).replace("\n", " "), "手动粘贴", t)
                    refresh()
                }
            }
            .setNegativeButton("取消", null).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 9 || resultCode != RESULT_OK || data == null) return
        val uris: List<Uri> = data.clipData?.let { c -> (0 until c.itemCount).map { c.getItemAt(it).uri } }
            ?: listOfNotNull(data.data)
        work("导入中…") {
            var n = 0
            for (u in uris) { Library.importUri(this@LibraryActivity, u); n++ }
            refresh()
            "已导入 $n 个文件"
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
