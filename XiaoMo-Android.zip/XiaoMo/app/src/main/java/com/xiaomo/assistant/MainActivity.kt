package com.xiaomo.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { fitsSystemWindows = true; addView(col) })

        fun label(t: String, size: Float = 16f) =
            col.addView(TextView(this).apply { text = t; textSize = size })

        fun field(hint: String, key: String, def: String): EditText {
            val e = EditText(this).apply {
                this.hint = hint
                setText(Prefs.get(this@MainActivity, key, def))
                setSingleLine()
            }
            col.addView(e)
            return e
        }

        fun button(t: String, f: () -> Unit) =
            col.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        label("小墨 · 语音助手", 22f)
        status = TextView(this).apply { textSize = 14f }
        col.addView(status)

        label("云端模型(OpenAI 兼容接口)")
        val url = field("Base URL", "base_url", "https://api.deepseek.com/v1")
        val key = field("API Key", "api_key", "")
        val model = field("模型名", "model", "deepseek-chat")
        val searx = field("搜索引擎地址(SearXNG,留空=DuckDuckGo)", "searx_url", "")

        fun save() {
            Prefs.put(this, "base_url", url.text.toString().trim())
            Prefs.put(this, "api_key", key.text.toString().trim())
            Prefs.put(this, "model", model.text.toString().trim())
            Prefs.put(this, "searx_url", searx.text.toString().trim())
        }

        fun startVoice(cmd: String?) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "请先授权麦克风", Toast.LENGTH_SHORT).show(); return
            }
            save()
            val i = Intent(this, VoiceService::class.java)
            if (cmd != null) i.putExtra("cmd", cmd)
            startForegroundService(i)
        }

        button("1. 授权麦克风 / 通知") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        button("2. 开启无障碍服务") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        button("3. 忽略电池优化") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }
        button("保存并启动小墨") { startVoice(null) }
        button("停止小墨") { stopService(Intent(this, VoiceService::class.java)) }
        button("📖 小说 / 🎭 角色扮演 / 朗读") { startActivity(Intent(this, StoryActivity::class.java)) }
        button("📚 资料库 / 联网搜索 / 下载") { startActivity(Intent(this, LibraryActivity::class.java)) }

        val cmd = EditText(this).apply { hint = "文字指令(不用说话也能测试)"; setSingleLine() }
        col.addView(cmd)
        button("执行文字指令") { startVoice(cmd.text.toString()) }
    }

    override fun onResume() {
        super.onResume()
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val acc = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(packageName)
        val mdl = !assets.list("model-cn").isNullOrEmpty()
        status.text = "麦克风:${if (mic) "✓" else "✗"}   无障碍:${if (acc) "✓" else "✗"}   语音模型:${if (mdl) "✓" else "✗"}"
    }
}
