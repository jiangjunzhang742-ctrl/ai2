package com.xiaomo.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * 朗读器。
 * - 剧本格式「名字:台词」「旁白:描写」:每个角色固定一个声音 + 音调;旁白用主音色
 * - 引号格式:旁白与“台词”两种声音
 * 设备有多个中文离线音色就轮流分配,否则只靠音调区分。
 */
class Reader(ctx: Context) : TextToSpeech.OnInitListener {
    private class Seg(val text: String, val who: Int) // who: -1 旁白, 0.. 说话人序号

    private val tts = TextToSpeech(ctx, this)
    private var ready = false
    private var narrator: Voice? = null
    private var pool: List<Voice> = emptyList()
    private val pitches = floatArrayOf(1.2f, 0.85f, 1.4f, 0.95f, 1.1f, 0.75f)
    var rate = 1.0f

    private val label = Regex("^([^\\n:：“「\"]{1,8})[:：]\\s*(.*)$")
    private val narrationNames = setOf("旁白", "叙述", "叙事")

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.setLanguage(Locale.CHINA)
        try {
            val zh = (tts.voices ?: emptySet<Voice>())
                .filter { it.locale.language == "zh" && !it.isNetworkConnectionRequired }
                .sortedBy { it.name }
            narrator = zh.getOrNull(0)
            pool = zh.drop(1)
        } catch (e: Exception) { }
        ready = true
    }

    fun speak(text: String) {
        if (!ready) return
        tts.stop()
        var i = 0
        for (seg in split(text)) {
            tts.setSpeechRate(rate)
            val v = if (seg.who < 0) narrator else pool.getOrNull(seg.who % maxOf(pool.size, 1))
            if (v != null) tts.setVoice(v) else narrator?.let { tts.setVoice(it) }
            tts.setPitch(if (seg.who < 0) 1.0f else pitches[seg.who % pitches.size])
            tts.speak(seg.text, TextToSpeech.QUEUE_ADD, null, "u${i++}")
        }
    }

    fun stop() { tts.stop() }
    fun shutdown() { tts.stop(); tts.shutdown() }

    private fun split(text: String): List<Seg> {
        val clean = text.replace(Regex("[*#_`]"), "")
        val out = ArrayList<Seg>()
        fun add(s: String, who: Int) { chunk(s).forEach { out.add(Seg(it, who)) } }
        val lines = clean.lines().map { it.trim() }.filter { it.isNotEmpty() }

        if (lines.any { label.matches(it) }) {            // 剧本模式
            val speakers = LinkedHashMap<String, Int>()
            for (line in lines) {
                val m = label.find(line)
                if (m == null) { add(line, -1); continue }
                val name = m.groupValues[1].trim()
                val body = m.groupValues[2].trim('“', '”', '「', '」', '"', ' ')
                if (name in narrationNames) add(body, -1)
                else add(body, speakers.getOrPut(name) { speakers.size })
            }
            return out
        }

        var last = 0                                       // 引号模式
        for (m in Regex("[“「\"][^”」\"]*[”」\"]").findAll(clean)) {
            add(clean.substring(last, m.range.first), -1)
            add(m.value.trim('“', '”', '「', '」', '"'), 0)
            last = m.range.last + 1
        }
        add(clean.substring(last), -1)
        return out
    }

    private fun chunk(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (p in s.split(Regex("(?<=[。!?！？\n])"))) {
            if (sb.isNotEmpty() && sb.length + p.length > 120) { out.add(sb.toString()); sb.clear() }
            sb.append(p)
        }
        if (sb.isNotBlank()) out.add(sb.toString())
        return out.filter { it.isNotBlank() }
    }
}
