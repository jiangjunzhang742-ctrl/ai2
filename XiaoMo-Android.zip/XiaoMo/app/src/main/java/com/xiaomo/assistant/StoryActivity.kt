package com.xiaomo.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.View
import android.widget.*
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class StoryActivity : Activity() {
    private val scope = MainScope()
    private lateinit var reader: Reader
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var name: EditText
    private lateinit var card: EditText
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var auto: CheckBox
    private var novelMode = true
    private var started = false
    private lateinit var tools: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        reader = Reader(this)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            fitsSystemWindows = true
        }
        setContentView(root)

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        fun row(vararg v: View): LinearLayout {
            val l = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                v.forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
            }
            root.addView(l)
            return l
        }

        row(btn("📖 写小说") { setMode(true) }, btn("🎭 角色扮演") { setMode(false) })

        name = EditText(this).apply {
            hint = "作品名(不同名字 = 不同小说)"
            setText(Prefs.get(this@StoryActivity, "novel_name", "我的小说"))
            setSingleLine()
            setOnFocusChangeListener { _, focus -> if (!focus) { saveName(); refresh() } }
        }
        root.addView(name)

        card = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            maxLines = 5
        }
        root.addView(card)

        log = TextView(this).apply { textSize = 16f; setTextIsSelectable(true) }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        input = EditText(this).apply { inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; maxLines = 3 }
        root.addView(input)

        send = btn("续写") { doSend() }
        row(send, btn("🎤 语音输入") { mic() })

        auto = CheckBox(this).apply { text = "自动朗读"; isChecked = true }
        row(btn("▶ 朗读最新") { reader.speak(Story.latest(this, novelMode)) }, btn("■ 停止") { reader.stop() }, auto)

        val speed = SeekBar(this).apply {
            max = 10
            progress = 4
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { reader.rate = 0.6f + p * 0.1f }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        row(TextView(this).apply { text = "语速" }, speed)
        row(btn("清空角色扮演对话") { Story.clearRoleplay(this); refresh() })

        val useLib = CheckBox(this).apply {
            text = "用资料库"
            isChecked = Prefs.get(this@StoryActivity, "use_lib", "1") == "1"
            setOnCheckedChangeListener { _, c -> Prefs.put(this@StoryActivity, "use_lib", if (c) "1" else "0") }
        }
        val useWeb = CheckBox(this).apply {
            text = "联网参考"
            isChecked = Prefs.get(this@StoryActivity, "use_web", "0") == "1"
            setOnCheckedChangeListener { _, c -> Prefs.put(this@StoryActivity, "use_web", if (c) "1" else "0") }
        }
        row(useLib, useWeb, btn("📚 资料库") { startActivity(Intent(this, LibraryActivity::class.java)) })

        tools = row(
            btn("＋新章节") {
                saveCard()
                val hint = input.text.toString().trim()
                input.setText("")
                busy {
                    val out = Story.newChapter(this@StoryActivity, hint)
                    refresh()
                    showRefs()
                    if (auto.isChecked) reader.speak(out)
                }
            },
            btn("生成大纲") {
                saveCard()
                busy {
                    Story.outline(this@StoryActivity)
                    card.setText(Prefs.get(this@StoryActivity, "novel_set", ""))
                    Toast.makeText(this@StoryActivity, "大纲已加入设定", Toast.LENGTH_SHORT).show()
                }
            },
            btn("导出 txt") {
                val p = Story.export(this)
                Toast.makeText(this, p?.let { "已导出到 $it" } ?: "导出需要 Android 10+", Toast.LENGTH_LONG).show()
            }
        )

        setMode(true)
        started = true
    }

    private fun setMode(novel: Boolean) {
        if (started) saveCard()
        novelMode = novel
        card.setText(Prefs.get(this, if (novel) "novel_set" else "rp_card", ""))
        card.hint = if (novel) "世界观 / 人物 / 大纲(越具体越好,长篇靠它保持一致)" else "角色卡:名字、性格、说话方式、与你的关系、当前场景"
        input.hint = if (novel) "本次要求(留空 = 自然续写),如:写主角第一次进入古城" else "你想对角色说的话(留空 = 让角色先开口)"
        name.visibility = if (novel) View.VISIBLE else View.GONE
        tools.visibility = if (novel) View.VISIBLE else View.GONE
        send.text = if (novel) "续写" else "发送"
        refresh()
    }

    private fun saveCard() = Prefs.put(this, if (novelMode) "novel_set" else "rp_card", card.text.toString())
    private fun saveName() = Prefs.put(this, "novel_name", name.text.toString().trim().ifEmpty { "我的小说" })

    private fun refresh() {
        log.text = if (novelMode) Story.novelText(this).ifBlank { "(还没有正文,点「续写」开始)" }
        else Story.transcript(this).ifBlank { "(还没有对话,点「发送」,留空则让角色先开口)" }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun doSend() {
        saveCard(); saveName()
        val text = input.text.toString().trim()
        input.setText("")
        send.isEnabled = false
        send.text = "生成中…"
        scope.launch {
            try {
                val out = if (novelMode) Story.novel(this@StoryActivity, text)
                else Story.roleplay(this@StoryActivity, text.ifBlank { Story.OPENER })
                refresh()
                showRefs()
                if (auto.isChecked) reader.speak(out)
            } catch (e: Exception) {
                Toast.makeText(this@StoryActivity, "出错:${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                send.isEnabled = true
                send.text = if (novelMode) "续写" else "发送"
            }
        }
    }

    /** 生成后提示这次实际参考了哪些资料。 */
    private fun showRefs() {
        val parts = Library.lastUsed.map { "《$it》" } + if (Refs.usedWeb) listOf("联网搜索") else emptyList()
        if (parts.isNotEmpty()) Toast.makeText(this, "本次参考:" + parts.joinToString(" "), Toast.LENGTH_LONG).show()
    }

    private fun busy(f: suspend () -> Unit) {
        send.isEnabled = false
        scope.launch {
            try { f() }
            catch (e: Exception) { Toast.makeText(this@StoryActivity, "出错:${e.message}", Toast.LENGTH_LONG).show() }
            finally { send.isEnabled = true }
        }
    }

    private fun mic() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN")
        try { startActivityForResult(i, 7) }
        catch (e: Exception) { Toast.makeText(this, "系统没有语音输入服务,可用输入法自带的麦克风", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input.setText(it) }
        }
    }

    override fun onPause() { reader.stop(); super.onPause() }
    override fun onDestroy() { scope.cancel(); reader.shutdown(); super.onDestroy() }
}
