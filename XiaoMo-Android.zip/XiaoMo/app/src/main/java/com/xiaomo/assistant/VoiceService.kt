package com.xiaomo.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/** 前台麦克风服务:本地 Vosk 持续监听唤醒词「小墨」→ 听指令 → 交给 Agent 执行。 */
class VoiceService : Service(), TextToSpeech.OnInitListener {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var model: Model? = null
    private var speech: SpeechService? = null
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var working = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("xm", "小墨", NotificationManager.IMPORTANCE_LOW))
        ServiceCompat.startForeground(this, 1, notif("小墨正在加载…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
        scope.launch { loadModel(); startWake() }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) { tts.setLanguage(Locale.CHINA); ttsReady = true }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.getStringExtra("cmd")?.takeIf { it.isNotBlank() }?.let { c ->
            if (!working) {
                working = true
                scope.launch { stopSpeech(); execute(c) }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        stopSpeech()
        model?.close()
        tts.shutdown()
        super.onDestroy()
    }

    // ---------- 唤醒 ----------
    private fun startWake() {
        val m = model ?: return
        stopSpeech()
        try {
            val rec = Recognizer(m, 16000f, "[\"小 墨\", \"小 莫\", \"小 默\", \"[unk]\"]")
            speech = SpeechService(rec, 16000f).also { s ->
                s.startListening(object : RecognitionListener {
                    override fun onPartialResult(h: String?) { if (isWake(h)) onWake() }
                    override fun onResult(h: String?) { if (isWake(h)) onWake() }
                    override fun onFinalResult(h: String?) {}
                    override fun onError(e: Exception?) { notify("麦克风出错:${e?.message}") }
                    override fun onTimeout() {}
                })
            }
        } catch (e: Exception) {
            notify("无法监听麦克风:${e.message}(请检查权限,或是否被其他应用占用)")
        }
    }

    private fun isWake(h: String?): Boolean {
        val j = JSONObject(h ?: "{}")
        val t = (j.optString("text").ifEmpty { j.optString("partial") }).replace(" ", "")
        return t.contains("小墨") || t.contains("小莫") || t.contains("小默")
    }

    private fun onWake() {
        if (working) return
        working = true
        stopSpeech()
        scope.launch {
            say("我在")
            val cmd = listenOnce()
            if (cmd.isNullOrBlank()) { working = false; startWake() } else execute(cmd)
        }
    }

    /** 唤醒后:用完整词表听一句指令,最长 8 秒。 */
    private suspend fun listenOnce(): String? = suspendCancellableCoroutine { c ->
        val m = model
        if (m == null) { c.resume(null); return@suspendCancellableCoroutine }
        val svc = SpeechService(Recognizer(m, 16000f), 16000f)
        var done = false
        fun finish(t: String?) {
            if (done) return
            done = true
            svc.stop(); svc.shutdown()
            if (c.isActive) c.resume(t)
        }
        fun text(h: String?) = JSONObject(h ?: "{}").optString("text").replace(" ", "")
        svc.startListening(object : RecognitionListener {
            override fun onPartialResult(h: String?) {}
            override fun onResult(h: String?) { val t = text(h); if (t.isNotBlank()) finish(t) }
            override fun onFinalResult(h: String?) { finish(text(h).ifBlank { null }) }
            override fun onError(e: Exception?) { finish(null) }
            override fun onTimeout() { finish(null) }
        }, 8000)
        c.invokeOnCancellation { finish(null) }
    }

    // ---------- 执行 ----------
    private suspend fun execute(first: String) {
        var next: String? = first
        while (true) {
            val cmd = next?.takeIf { it.isNotBlank() } ?: break
            notify("执行中:$cmd")
            val reply = try {
                Agent.run(this, cmd) { say(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                "出错了:${e.message}"
            }
            say(reply)
            // 角色扮演中:不用再喊唤醒词,直接接着听下一句
            next = if (Story.roleplayActive) { notify("角色扮演中,直接说话,说“结束”退出"); listenOnce() } else null
        }
        working = false
        notify("小墨待命中,说“小墨”唤醒")
        startWake()
    }

    private suspend fun say(text: String) {
        for (chunk in chunks(text)) withTimeoutOrNull(45_000) { sayOne(chunk) }
    }

    private fun chunks(t: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (s in t.replace(Regex("[*#_`]"), "").replace(Regex("(?m)^[^\\n:：“「]{1,8}[:：]\\s*"), "").split(Regex("(?<=[。!?！？\n])"))) {
            if (sb.isNotEmpty() && sb.length + s.length > 150) { out.add(sb.toString()); sb.clear() }
            sb.append(s)
        }
        if (sb.isNotBlank()) out.add(sb.toString())
        return out
    }

    private suspend fun sayOne(text: String) = suspendCancellableCoroutine<Unit> { c ->
        if (!ttsReady || text.isBlank()) { c.resume(Unit); return@suspendCancellableCoroutine }
        val id = UUID.randomUUID().toString()
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {}
            override fun onDone(u: String?) { if (u == id && c.isActive) c.resume(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(u: String?) { if (u == id && c.isActive) c.resume(Unit) }
        })
        if (tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) != TextToSpeech.SUCCESS && c.isActive) c.resume(Unit)
    }

    // ---------- 模型 / 通知 ----------
    private suspend fun loadModel() = withContext(Dispatchers.IO) {
        try {
            val dst = File(filesDir, "model-cn")
            if (!File(dst, ".ok").exists()) {
                if (assets.list("model-cn").isNullOrEmpty()) { notify("缺少语音模型,见 README"); return@withContext }
                copyAssets("model-cn", dst)
                File(dst, ".ok").writeText("1")
            }
            model = Model(dst.absolutePath)
            notify("小墨待命中,说“小墨”唤醒")
        } catch (e: Throwable) {
            notify("模型加载失败:${e.message}")
        }
    }

    private fun copyAssets(src: String, dst: File) {
        val list = assets.list(src) ?: return
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            assets.open(src).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            list.forEach { copyAssets("$src/$it", File(dst, it)) }
        }
    }

    private fun stopSpeech() {
        speech?.let { it.stop(); it.shutdown() }
        speech = null
    }

    private fun notif(text: String): Notification =
        NotificationCompat.Builder(this, "xm")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("小墨")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun notify(text: String) =
        getSystemService(NotificationManager::class.java).notify(1, notif(text))
}
